import 'package:app1/widgets/actions_section/actions_section.dart';
import 'package:app1/widgets/custom_app_bar/custom_app_bar.dart';
import 'package:app1/widgets/customers_list/customers_list.dart';
import 'package:app1/widgets/tags_section/tags_section.dart';
import 'package:flutter/material.dart';

class CustomersScreen extends StatelessWidget {
  const CustomersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  TagsSection(),
                  SizedBox(height: 24),
                  ActionsSection(),
                  SizedBox(height: 24),
                  CustomersList(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
