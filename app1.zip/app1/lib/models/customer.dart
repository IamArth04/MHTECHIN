class Customer {
  final String name;
  final String avatarUrl;
  final List<String> tags;

  Customer({
    required this.name,
    required this.avatarUrl,
    required this.tags,
  });
}
