import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/customers_screen/customers_screen.dart';
import 'viewmodels/customers_view_model.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CustomersViewModel(),
      child: MaterialApp(
        title: 'Customer Management',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
          scaffoldBackgroundColor: Colors.white,
        ),
        home: const CustomersScreen(),
      ),
    );
  }
}
