import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/customers_view_model.dart';
import '../customer_card/customer_card.dart';

class CustomersList extends StatelessWidget {
  const CustomersList({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<CustomersViewModel>(
      builder: (context, viewModel, _) {
        return Column(
          children: viewModel.customers
              .map(
                (customer) => CustomerCard(
                  name: customer.name,
                  avatarUrl: customer.avatarUrl,
                  tags: customer.tags,
                ),
              )
              .toList(),
        );
      },
    );
  }
}
