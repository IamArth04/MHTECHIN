import 'package:flutter/material.dart';
import '../action_button/action_button.dart';

class ActionsSection extends StatelessWidget {
  const ActionsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Actions',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            ActionButton(
              icon: Icons.person_add,
              label: 'Assign to',
              color: Colors.black,
              onPressed: () {},
            ),
            ActionButton(
              icon: Icons.notifications,
              label: 'Reminders',
              color: Colors.black,
              onPressed: () {},
            ),
            ActionButton(
              icon: Icons.send,
              label: 'Send a message',
              color: Colors.black,
              onPressed: () {},
            ),
          ],
        ),
      ],
    );
  }
}
