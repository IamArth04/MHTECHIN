import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/customers_view_model.dart';
import '../tag_chip/tag_chip.dart';

class TagsSection extends StatelessWidget {
  const TagsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Tags',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Consumer<CustomersViewModel>(
          builder: (context, viewModel, _) {
            return Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  viewModel.allTags.map((tag) => TagChip(tag: tag)).toList(),
            );
          },
        ),
      ],
    );
  }
}
