import 'package:flutter/foundation.dart';
import '../models/customer.dart';

class CustomersViewModel extends ChangeNotifier {
  final List<Customer> _customers = [
    Customer(
      name: 'Beby Jovanca',
      avatarUrl: 'assets/avatar_1.png',
      tags: [
        'InspireDaily',
        'Mindful',
        'TechTalk',
        'Gratitude',
        'ConnectionGoals'
      ],
    ),
    Customer(
      name: 'Nancy Green',
      avatarUrl: 'assets/avatar_2.png',
      tags: [
        'InspireDaily',
        'Mindful',
        'TechTalk',
        'Gratitude',
        'ConnectionGoals'
      ],
    ),
  ];

  List<Customer> get customers => _customers;

  final List<String> _allTags = [
    'TechTalk',
    'Gratitude',
    'Mindful',
    'InspireDaily',
    'ConnectionGoals',
  ];

  List<String> get allTags => _allTags;
}
